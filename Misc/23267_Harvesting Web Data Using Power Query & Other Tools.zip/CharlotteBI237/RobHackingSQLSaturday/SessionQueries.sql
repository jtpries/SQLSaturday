/*	Hacking SQL Saturday
	Session Queries
*/

-- Be sure to import into SQLSatXML table first
USE HackingSQLSat;

--session data
WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, EventsXML AS (SELECT n, 
	xml.query('//events') Events, 
	xml.value('(//guide/startDate)[1]','date') EventDate
FROM SQLSat)
, EventDetails AS (SELECT e.n, 
	e.EventDate, 
	e2.eXml.query('*') SessionXML
FROM EventsXML E 
	CROSS APPLY E.Events.nodes('//event') E2(eXML))
SELECT *, SessionXML.value('(importID)[1]','int') SessionID
FROM EventDetails;

--session details
WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, EventsXML AS (SELECT n, 
	xml.query('//events') Events, 
	xml.value('(//guide/startDate)[1]','date') EventDate
FROM SQLSat)
, EventDetails AS (SELECT e.n, 
	e.EventDate, 
	e2.eXml.query('*') SessionXML
FROM EventsXML E 
	CROSS APPLY E.Events.nodes('//event') E2(eXML))
SELECT n, EventDate, 
	SessionXML.value('(importID)[1]','int') SessionID,
	SessionXML.value('(track)[1]','varchar(80)') Track,
	SessionXML.value('(title)[1]','varchar(80)') Title,
	SessionXML.value('(description)[1]','varchar(1024)') Description,
	SessionXML.value('(/speakers/speaker/name)[1]','varchar(80)') Speaker,
	SessionXML.value('(/location/name)[1]','varchar(80)') Location,
	SessionXML.value('(startTime)[1]','time(0)') StartTime,
	SessionXML.value('(endTime)[1]','time(0)') EndTime
FROM EventDetails;

-- do we have any with 2 speakers?
WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, EventsXML AS (SELECT n, 
	xml.query('//events') Events, 
	xml.value('(//guide/startDate)[1]','date') EventDate
FROM SQLSat)
, EventDetails AS (SELECT e.n, 
	e.EventDate, 
	e2.eXml.query('*') SessionXML
FROM EventsXML E 
	CROSS APPLY E.Events.nodes('//event') E2(eXML))
SELECT n, EventDate, 
	SessionXML.value('(importID)[1]','int') SessionID,
	SessionXML.value('(track)[1]','varchar(80)') Track,
	SessionXML.value('(title)[1]','varchar(80)') Title,
	SessionXML.value('(description)[1]','varchar(1024)') Description,
	SessionXML.value('(/speakers/speaker/name)[1]','varchar(80)') Speaker1,
	SessionXML.value('(/speakers/speaker/name)[2]','varchar(80)') Speaker2,  -- notice the [2] instead of [1]
	SessionXML.value('(/location/name)[1]','varchar(80)') Location,
	SessionXML.value('(startTime)[1]','time(0)') StartTime,
	SessionXML.value('(endTime)[1]','time(0)') EndTime
FROM EventDetails;

-- aggregate: speaker with most sessions
WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, EventsXML AS (SELECT n, 
	xml.query('//events') Events, 
	xml.value('(//guide/startDate)[1]','date') EventDate
FROM SQLSat)
, EventDetails AS (SELECT e.n, 
	e.EventDate, 
	e2.eXml.query('*') SessionXML
FROM EventsXML E 
	CROSS APPLY E.Events.nodes('//event') E2(eXML))
, SessionDetails AS (SELECT n, EventDate, 
	SessionXML.value('(/speakers/speaker/name)[1]','varchar(80)') Speaker
FROM EventDetails)
SELECT Speaker, 
	COUNT(*) Sessions,
	COUNT(DISTINCT n) Events,
	MIN(EventDate) Earliest,
	MAX(EventDate) Latest
--INTO #speakers
FROM SessionDetails
GROUP BY Speaker
ORDER BY Events DESC, Sessions DESC, Speaker;

SELECT *
FROM #speakers 
ORDER BY Events DESC, Sessions DESC, Speaker;

SELECT *, SUM(Sessions) OVER() TotalSessionss, SUM(Events) OVER() TotalEvents 
FROM #speakers
WHERE Speaker LIKE '%[BW]ill%Pearson%'


-- aggregate: event with most sessions (includes lunch, keynotes)
WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, EventsXML AS (SELECT n, 
	xml.query('//events') Events, 
	xml.value('(//guide/name)[1]','varchar(100)') Event,
	xml.value('(//guide/startDate)[1]','date') EventDate
FROM SQLSat)
, EventDetails AS (SELECT e.n, e.Event,
	e.EventDate, 
	e2.eXml.query('*') SessionXML
FROM EventsXML E 
	CROSS APPLY E.Events.nodes('//event') E2(eXML))
, Sessions AS (SELECT n, EventDate, Event,
	SessionXML.value('(importID)[1]','int') SessionID
FROM EventDetails)
SELECT n, Event, COUNT(DISTINCT SessionID) Sessions
FROM Sessions
GROUP BY n, Event
ORDER BY Sessions DESC;


-- Mladen's sessions
WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, EventsXML AS (SELECT n, 
	xml.query('//events') Events, 
	xml.value('(//guide/startDate)[1]','date') EventDate,
	xml.value('(//guide/name)[1]','varchar(100)') EventName
FROM SQLSat)
, EventDetails AS (SELECT e.n, e.EventName,
	e.EventDate, 
	e2.eXml.query('*') SessionXML
FROM EventsXML E 
	CROSS APPLY E.Events.nodes('//event') E2(eXML))
, SessionDetails AS (SELECT n, EventDate, EventName,
	SessionXML.value('(/speakers/speaker/name)[1]','varchar(80)') Speaker,
--	SessionXML.query('*') XMLDetails,
	SessionXML.value('(/title)[1]','varchar(200)') SessionTitle
FROM EventDetails)
SELECT *
FROM SessionDetails
WHERE Speaker LIKE '%Mladen%'

