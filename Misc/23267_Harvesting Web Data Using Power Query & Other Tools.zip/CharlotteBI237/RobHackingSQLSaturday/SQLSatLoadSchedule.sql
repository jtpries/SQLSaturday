drop table #a
create table #a(x nvarchar(max),i tinyint not null identity(1,1) primary key)
declare @sql varchar(max)=''
;with n(n) as (select 1 union all select n+1 from n where n<132)
select @sql=@sql+'bulk insert #a from ''d:\sqlsat\sched' + cast(n as varchar(3)) + '.htm'' with (codepage=''RAW'', rowterminator='''', fieldterminator='''', formatfile=''d:\sqlsat\sqlsat.fmt'');'
from n option (maxrecursion 150)
print @sql
exec(@sql)
--alter table #a add i tinyint not null identity(1,1) primary key

select i, cast(replace(SUBSTRING(x,patindex('%gridview2%',x),CHARINDEX('</tr>',x,patindex('%gridview2%',x))-patindex('%gridview2%',x)+5) ,'GridView2">
		','') as xml)
from #a
