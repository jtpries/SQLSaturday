-- exec master..xp_cmdshell 'for %a in (d:\sqlsat\*.xml) do @echo insert sqlsat(num,event_xml) select %~na, CAST(a.x as xml) from openrowset(BULK ''%a'', SINGLE_CLOB) AS A(x)'
-- create table sqlsat(num tinyint not null primary key, event_xml xml null)
--;with n(n) as (select 1 union all select n+1 from n where n<200) select n from n left join sqlsat s on n.n=s.num where s.num is null option (maxrecursion 300)

select * from sqlsat s 
cross apply s.event_xml.nodes('//sponsors') as x
where s.num=111