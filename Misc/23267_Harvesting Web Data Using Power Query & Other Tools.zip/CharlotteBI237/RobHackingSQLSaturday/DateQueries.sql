/*	Hacking SQL Saturday
	Import XML Files to table
*/

-- Date queries
USE HackingSQLSat;

-- Pivot by month and year
with SQLSatRaw(n,x) as (select n, CAST(x as xml) x from SQLSatXML)
, SQLSatVenue as (
select n, x.value('(//guide/name)[1]','varchar(100)') Event,
x.value('(//guide/startDate)[1]','date') Date,
x.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
x.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
x.value('(//venue/city)[1]', 'nvarchar(50)') City,
x.value('(//venue/state)[1]', 'nvarchar(50)') State,  
x.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
from SQLSatRaw)
select yr Year, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov+Dec TotalForYear
from (select YEAR(date) yr, left(datename(month,date),3) month from SQLSatVenue) a
pivot(count(month) for month
in ([Jan],[Feb],[Mar],[Apr],[May],[Jun],[Jul],[Aug],[Sep],[Oct],[Nov],[Dec])) b;

-- Upcoming
with SQLSatRaw(n,x) as (select n, CAST(x as xml) x from SQLSatXML)
, SQLSatVenue as (
select n, x.value('(//guide/name)[1]','varchar(100)') Event,
x.value('(//guide/startDate)[1]','date') Date,
x.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
x.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
x.value('(//venue/city)[1]', 'nvarchar(50)') City,
x.value('(//venue/state)[1]', 'nvarchar(50)') State,  
x.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
from SQLSatRaw)
SELECT * FROM SQLSatVenue
WHERE Date>=CAST(GETDATE() as date)
ORDER BY Date, City;

