/*	Hacking SQL Saturday
	DDL

Well, all these XML queries are kinda complicated!

What can we learn from this:
- we have structured data for SQL Saturday
- ImportID appears to be the primary key for each section
- CAN WE MAKE OUR OWN RELATIONAL TABLES FOR THIS DATA???
-- Events
-- Speakers
-- Sessions
-- Sponsors

*/

USE HackingSQLSat;

-- DROP TABLE Events;
CREATE TABLE Events(# int NOT NULL CONSTRAINT PK_Events PRIMARY KEY,
EventName varchar(80) not null,
EventDate date not null,
VenueName varchar(120) null,
Street varchar(120) null,
City varchar(80) null,
State varchar(30) null,
Zip varchar(20) null);
GO

CREATE TABLE EventSpeakers(# int NOT NULL, SpeakerID int not null CONSTRAINT PK_EventSpeakers PRIMARY KEY,
Speaker nvarchar(128) NOT NULL);

-- DROP TABLE EventSessions;
CREATE TABLE EventSessions(# int NOT NULL, SessionID int not null, --CONSTRAINT PK_EventSessions PRIMARY KEY,
Speaker nvarchar(128) NOT NULL, SessionTitle nvarchar(128) NOT NULL, SessionDescription varchar(1024),
Track varchar(64), Location varchar(64), StartTime time(0), EndTime time(0));

CREATE TABLE EventSponsors(# int, SponsorID int NOT NULL CONSTRAINT PK_Sponsors PRIMARY KEY, 
Sponsor varchar(128), Level varchar(80));

-- Insert data from XML source

--session details
WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, EventsXML AS (SELECT n, 
	xml.query('//events') Events, 
	xml.value('(//guide/startDate)[1]','date') EventDate
FROM SQLSat)
, EventDetails AS (SELECT e.n, 
	e.EventDate, 
	e2.eXml.query('*') SessionXML
FROM EventsXML E 
	CROSS APPLY E.Events.nodes('//event') E2(eXML))
INSERT EventSessions(#,SessionID,Track,SessionTitle,SessionDescription,Speaker,Location,StartTime,EndTime)
SELECT n, 
	SessionXML.value('(importID)[1]','int') SessionID,
	SessionXML.value('(track)[1]','varchar(80)') Track,
	SessionXML.value('(title)[1]','varchar(80)') Title,
	SessionXML.value('(description)[1]','varchar(1024)') Description,
	SessionXML.value('(/speakers/speaker/name)[1]','varchar(80)') Speaker,
	SessionXML.value('(/location/name)[1]','varchar(80)') Location,
	SessionXML.value('(startTime)[1]','time(0)') StartTime,
	SessionXML.value('(endTime)[1]','time(0)') EndTime
FROM EventDetails;

SELECT * FROM EventSessions;
