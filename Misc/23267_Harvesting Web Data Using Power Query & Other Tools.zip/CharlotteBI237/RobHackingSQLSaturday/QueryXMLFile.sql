/*	Hacking SQL Saturday
	Query XML files directly (OPENROWSET BULK)
*/

-- command line (download CURL first):
-- for %a in (173 237) do curl -o %a.xml http://sqlsaturday.com/eventxml.aspx?sat=%a

-- query XML files directly:
WITH SQLSat(n,XML) AS (SELECT 174 n, CAST(XML AS XML) XML
FROM OPENROWSET(BULK N'c:\HackingSQLSaturday\174.xml', single_clob) x(XML))
SELECT n, xml FROM SQLSat;

WITH SQLSat(n,XML) AS (SELECT 237 n, CAST(XML AS XML) XML
FROM OPENROWSET(BULK N'c:\HackingSQLSaturday\237.xml', single_clob) x(XML))
SELECT n, xml FROM SQLSat;

-- parse some XML data:
WITH SQLSat(n,XML) AS (SELECT 174 n, CAST(XML AS XML) XML
FROM OPENROWSET(BULK N'c:\HackingSQLSaturday\174.xml', single_clob) x(XML))
SELECT n, 
	xml.value('(//guide/name)[1]','varchar(100)') Event,
	xml.value('(//guide/startDate)[1]','date') Date,
--	xml.query('//venue') venue,
	xml.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
	xml.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
	xml.value('(//venue/city)[1]', 'nvarchar(50)') City,
	xml.value('(//venue/state)[1]', 'nvarchar(50)') STATE,  
	xml.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
FROM SQLSat;

WITH SQLSat(n,XML) AS (SELECT 237 n, CAST(XML AS XML) XML
FROM OPENROWSET(BULK N'c:\HackingSQLSaturday\237.xml', single_clob) x(XML))
SELECT n, 
	xml.value('(//guide/name)[1]','varchar(100)') Event,
	xml.value('(//guide/startDate)[1]','date') Date,
--	xml.query('//venue') venue,
	xml.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
	xml.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
	xml.value('(//venue/city)[1]', 'nvarchar(50)') City,
	xml.value('(//venue/state)[1]', 'nvarchar(50)') STATE,  
	xml.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
FROM SQLSat;
