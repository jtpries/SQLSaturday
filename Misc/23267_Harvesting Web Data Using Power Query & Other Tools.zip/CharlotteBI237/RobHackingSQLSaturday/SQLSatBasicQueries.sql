-- command line (download CURL first):
-- for /L %a in (1,1,249) do curl -o %a.xml http://sqlsaturday.com/eventxml.aspx?sat=%a

/* -- query XML files directly:
with SQLSat(n,xml) AS (select 115 n, CAST(xml as xml) xml
from openrowset(bulk 'c:\sqlsat\115.xml', single_clob) x(xml))
select n, xml.query('//venue') venue,
xml.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
xml.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
xml.value('(//venue/city)[1]', 'nvarchar(50)') City,
xml.value('(//venue/state)[1]', 'nvarchar(50)') State,  
xml.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
from SQLSat
*/

-- easier to import into a table
create table #sqlsat(n smallint not null primary key,x varchar(max) null)

-- loop through all events and insert
set nocount on
declare @n smallint=1, @sql nvarchar(max)

while @n<249 begin
	set @sql='select ' + CAST(@n as varchar) + 
		', * from openrowset(bulk ''c:\HackingSQLSaturday\' + cast(@n as varchar) +
		'.xml'', single_clob) x(xml)'
	insert #sqlsat exec(@sql)
	set @n+=1
end
delete #sqlsat where n=39 -- # 39 has corrupted data

-- now we can query across all events:
with SQLSatRaw(n,x) as (select n, CAST(x as xml) x from #sqlsat)
, SQLSatVenue as (
select n, x.value('(//guide/name)[1]','varchar(100)') Event,
x.value('(//guide/startDate)[1]','date') Date,
x.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
x.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
x.value('(//venue/city)[1]', 'nvarchar(50)') City,
x.value('(//venue/state)[1]', 'nvarchar(50)') State,  
x.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
from SQLSatRaw)
--select * from SQLSatVenue
/*-- most popular cities
select city, COUNT(*) events, MIN(date) earliest, MAX(date) latest
from SQLSatVenue group by City order by COUNT(*) desc, City
*/
--select cast(DATEADD(month,datediff(month,0,date),0) as date) month, COUNT(*) Events
--from SQLSatVenue
--group by datediff(month,0,date) order by Events desc
-- pivot
select yr Year, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec 
from (select YEAR(date) yr, left(datename(month,date),3) month from SQLSatVenue) a
pivot(count(month) for month
in ([Jan],[Feb],[Mar],[Apr],[May],[Jun],[Jul],[Aug],[Sep],[Oct],[Nov],[Dec])) b

-- sponsor info
with SQLSatRaw(n,x) as (
select n, CAST(x as xml) x from #sqlsat)
, SponsorsXML as (select n, x.query('//sponsors') Sponsors, x.value('(//guide/startDate)[1]','date') EventDate
from SQLSatRaw)
, SponsorDetails as (select s.n, s.EventDate,
s2.Sponsors.value('(importID)[1]','int') ImportID,
s2.Sponsors.value('(name)[1]','varchar(80)') SponsorName,
s2.Sponsors.value('(label)[1]','varchar(80)') Level,
s2.Sponsors.value('(url)[1]','varchar(180)') URL,
s2.Sponsors.value('(imageURL)[1]','varchar(180)') ImageURL 
from SponsorsXML s 
cross apply s.Sponsors.nodes('//sponsor') s2(Sponsors))
--select * from SponsorDetails
/* -- different sponsorship levels
select Level, COUNT(*) Sponsors, count(distinct n) Events, MIN(n) earliest, MAX(n) latest
from SponsorDetails group by Level order by Level
*/
-- Sponsor by level
select SponsorName, Level, COUNT(*) Events, MIN(EventDate) earliest, MAX(EventDate) latest
from SponsorDetails 
group by Level, SponsorName order by COUNT(*) desc

--session details
with SQLSatRaw(n,x) as (
select n, CAST(x as xml) x from #sqlsat)
, EventsXML as (select n, x.query('//events') Events, x.value('(//guide/startDate)[1]','date') EventDate
from SQLSatRaw)
, EventDetails as (select e.n, e.EventDate, e2.eXml.query('*') SessionXML
from EventsXML E 
cross apply E.Events.nodes('//event') E2(eXML))
select *, 
SessionXML.value('(importID)[1]','int') SessionID
from EventDetails

-- well, all these XML queries are kinda complicated
-- what can we learn from this:
--- ImportID appears to be the primary key for each section
--- we have structured data for SQL Saturday
--- CAN WE MAKE OUR OWN RELATIONAL TABLES FOR THIS DATA???

-- and by the magic of SQL you do just that, and use the previous queries to populate them
-- do bulk loads from XML files, set up tables to ignore dup keys
-- once that's done, do the special import thing (download #237 after submission, show the update)