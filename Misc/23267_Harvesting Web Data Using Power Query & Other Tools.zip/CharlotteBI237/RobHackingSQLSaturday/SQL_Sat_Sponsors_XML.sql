declare @x xml='<table cellspacing="0" cellpadding="5" align="Center" id="ContentPlaceHolder1_GridView1" style="border-collapse:collapse;">
		<tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.intellinet.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_0" src="http://www.sqlsaturday.com/files/664ffcf1-25d1-4f88-b2d3-42b24fb76ca2.jpg" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Gold Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://mariner-usa.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_1" src="http://www.sqlsaturday.com/files/920106d8-a494-4724-a7d6-2d58de209d1e.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Gold Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.tekpartnersbi.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_2" src="http://www.sqlsaturday.com/files/1fe694d5-5770-47c6-b293-e88108a255c1.jpg" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Gold Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.sqlsentry.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_3" src="http://www.sqlsaturday.com/files/c1823b6b-e23a-4be8-a8cb-4cfea1a193eb.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Gold Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.entsoftsol.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_4" src="http://www.entsoftsol.com/logo170x60.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Gold Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.cardinalsolutions.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_5" src="http://www.sqlsaturday.com/files/5ca56613-1329-4fc6-b40f-24becd5ac7ec.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Gold Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.fusionio.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_6" src="http://www.sqlsaturday.com/files/298dd9dd-32b9-4081-b020-527624c25dec.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Silver Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.gridironsystems.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_7" src="http://www.sqlsaturday.com/files/d1aff1e0-dffd-46cd-b76c-f44f281ec341.jpg" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Silver Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.nhcharlotte.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_8" src="http://www.sqlsaturday.com/files/c8ac0a95-aace-463c-9f6c-87efa143a876.gif" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Silver Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.cozyroc.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_9" src="http://www.sqlsaturday.com/files/781fbe77-f6d2-41b3-8e26-b9686169e215.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Silver Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="https://www.captechconsulting.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_10" src="http://www.sqlsaturday.com/files/dfadf904-ac0f-4668-a7af-d199fa2da204.jpg" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Silver Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.varigence.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_11" src="http://www.sqlsaturday.com/files/c5e56b32-0f75-42a1-81b2-733577adeffa.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Silver Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.melissadata.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_12" src="http://www.melissadata.com/images/mdlogo-color-tag-170x60.gif" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Silver Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.blue-granite.com/site/Home/tabid/36/Default.aspx">
                            <img id="ContentPlaceHolder1_GridView1_Image1_13" src="http://melissacoates.squarespace.com/storage/BlueGranite_170x60.png" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Bronze Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.teksystems.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_14" src="http://www.sqlsaturday.com/files/611d5b35-1f6f-49c3-9016-1617e677f834.jpg" style="height:60px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Bronze Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.packtpub.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_15" src="http://melissacoates.squarespace.com/storage/Swag_Packt_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.pluralsight.com/training">
                            <img id="ContentPlaceHolder1_GridView1_Image1_16" src="http://melissacoates.squarespace.com/storage/Swag_Pluralsight_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.techsmith.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_17" src="http://www.sqlsaturday.com/files/34f87c66-5e73-4871-a86d-882fadd4d4b1.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.kimballgroup.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_18" src="http://melissacoates.squarespace.com/storage/Swag_KimballGroup_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.apress.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_19" src="http://melissacoates.squarespace.com/storage/Swag_APress_100x40.jpg" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.prologika.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_20" src="http://melissacoates.squarespace.com/storage/Swag_Prologika_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.mrexcel.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_21" src="http://melissacoates.squarespace.com/storage/Swag_MrExcel_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.quepublishing.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_22" src="http://melissacoates.squarespace.com/storage/Swag_Que_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.mhprofessional.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_23" src="http://melissacoates.squarespace.com/storage/Swag_McGrawHill_100x40.gif" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.red-gate.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_24" src="http://melissacoates.squarespace.com/storage/Swag_RedGateLogo_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://oreilly.com/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_25" src="http://melissacoates.squarespace.com/storage/Swag_OReillyLogo_100x40.gif" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.sapien.com/software/primalscript">
                            <img id="ContentPlaceHolder1_GridView1_Image1_26" src="http://melissacoates.squarespace.com/storage/Swag_SapienLogo_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.wrox.com/WileyCDA/">
                            <img id="ContentPlaceHolder1_GridView1_Image1_27" src="http://melissacoates.squarespace.com/storage/Swag_Wrox_100x40.gif" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Swag Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.sqlchick.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_28" src="http://melissacoates.squarespace.com/storage/SQLChick_Logo_100x40.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Blog Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://road-blogs.blogspot.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_29" src="https://xmp7ua.bay.livefilestore.com/y1pgMJIQLI5I7eTQiU9RbpQ8Eyu3GXt5jhk211KxpOxpxCClvTgKG2qGOJClvk8lUpaZiH57ym5jXXPqtgNwu_ZSKUSoQ1A9RK6/TitlImg.jpg" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Blog Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://javierguillen.files.wordpress.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_30" src="http://javierguillen.files.wordpress.com/2012/08/javilogo-e1344616159627.jpg" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Blog Sponsor</td>
		</tr><tr>
			<td align="left" valign="middle" style="width:20%;">
                        <a href="http://www.rafael-salas.com">
                            <img id="ContentPlaceHolder1_GridView1_Image1_31" src="http://www.sqlsaturday.com/files/d4e6e71c-6cc2-4dce-a746-e298c1a3f0ec.png" style="height:40px;" />
                        </a>
                    </td><td align="left" valign="middle" style="font-size:Large;width:30%;">Blog Sponsor</td>
		</tr>
	</table>'
--select DATALENGTH(@x)
--set @x=@x.query('table[1]')
-- xmlns="http://www.w3.org/1999/xhtml"
--set @x=@x.query('declare default element namespace "http://www.w3.org/1999/xhtml";//html')
--select @x
set @x=@x.query('//table')
set @x.modify('delete //@xmlns')
set @x.modify('delete //@id')
set @x.modify('delete //@align')
set @x.modify('delete //@valign')
set @x.modify('delete //@style');
;with cte as (select replace(x.value('td[2]','varchar(30)'),' Sponsor','') Sponsor
,x.value('td[1]/a[1]/@href','varchar(128)') url
,x.value('td[1]/a[1]/img[1]/@src','varchar(128)') img
from @x.nodes('table/tr') x(x))
select img, sponsor + '_' + replace(stuff(left(url,charindex('.com',url)-1),1,charindex('//',url)+1,''),'www.','') + '.' + parsename(img,1) 
from cte