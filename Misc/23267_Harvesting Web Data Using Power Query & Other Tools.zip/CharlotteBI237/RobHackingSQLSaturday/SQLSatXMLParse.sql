declare @x xml='<events><event sqlsat="10">
      <importID>299</importID>
      <speaker>Plamen Ratchev</speaker>
      <track>Track 2</track>
      <location>
        <name>Track 2</name>
      </location>
      <title>T-SQL Enhancements in SQL Server 2008</title>
      <description>This session will present new T-SQL enhancements in SQL Server 2008 including MERGE, table valued parameters, new data types (Date and Time related, FILESTREAM, HIERARCHYID), table value constructors, sparse columns, filtered indexes, delighters, and more.</description>
</event>
<event sqlsat="115">
      <importID>7029</importID>
      <speaker>Hugo Kornelis</speaker>
      <track>1. Dev</track>
      <location>
        <name>Room 1</name>
      </location>
      <title>All about MERGE</title>
      <description>The MERGE statement was introduced in SQL Server 2008, and it offers a tremendous value.
Most people do know the basic function of MERGE: synchronising imported data with base data by inserting new rows and updating existing rows, all in one go. But MERGE can do much, much more.
In this demo-rich session, Hugo Kornelis will present the full syntax of the MERGE statement, explain all the options, and show the possibilities. He will also demonstrate that the introduction of MERGE might have made your existing triggers incorrect, and how to fix the problems.</description>
</event>
<event sqlsat="121">
      <importID>6812</importID>
      <speaker>Wayne Sheffield</speaker>
      <track>DBA\Dev</track>
      <location>
        <name>30th Street</name>
      </location>
      <title>Minimally Invasive - Tools to Doctor Up Your Code</title>
      <description>This code filled session examines several additions to recent versions of SQL Server. These tools allow you to perform minimally invasive surgery on your code and gain performance! Learn how the APPLY operator works; iterate through incoming data just once with the MERGE statement; slice and dice your data with the Windowing (ranking) functions; re-write your multi-statement table-valued functions to inline functions to help the optimizer and speed up your queries; learn how to create a grouped delimited list ?�� without loops! </description>
</event>
<event sqlsat="135">
      <importID>8444</importID>
      <speaker>Rob Farley</speaker>
      <track>Business Intelligence </track>
      <location>
        <name>Room 2</name>
      </location>
      <title>The MERGE Statement - T-SQL''s Swiss Army Knife</title>
      <description>Despite being around since SQL Server 2008 MERGE is one of the most underappreciated features in T-SQL. In many ways it''s the Swiss Army Knife, able to be used in many different situations. It''s not without it''s frustrations though, and you''ll see both sides of this useful tool in this presentation.</description>
</event>
<event sqlsat="139">
      <importID>8471</importID>
      <speaker>Rob Farley</speaker>
      <track>Track 1</track>
      <location>
        <name>Cinema 3</name>
      </location>
      <title>The MERGE Statement - T-SQL''s Swiss Army Knife</title>
      <description>Despite being around since SQL Server 2008 MERGE is one of the most underappreciated features in T-SQL. In many ways it''s the Swiss Army Knife, able to be used in many different situations. It''s not without it''s frustrations though, and you''ll see both sides of this useful tool in this presentation.</description>
</event>
<event sqlsat="140">
      <importID>8482</importID>
      <speaker>Rob Farley</speaker>
      <track>SQL Server</track>
      <location>
        <name>T1</name>
      </location>
      <title>The MERGE Statement - T-SQL''s Swiss Army Knife</title>
      <description>Despite being around since SQL Server 2008 MERGE is one of the most underappreciated features in T-SQL. In many ways it''s the Swiss Army Knife, able to be used in many different situations. It''s not without it''s frustrations though, and you''ll see both sides of this useful tool in this presentation.</description>
</event>
<event sqlsat="15">
      <importID>360</importID>
      <speaker>Plamen Ratchev</speaker>
      <track>Room 1016 (Auditorium)</track>
      <location>
        <name>Room 1016</name>
      </location>
      <title>T-SQL Enhancements in SQL Server 2008</title>
      <description>This session will present new T-SQL enhancements in SQL Server 2008 including MERGE, table valued parameters, new data types (Date and Time related, FILESTREAM, HIERARCHYID), table value constructors, sparse columns, filtered indexes, delighters, and more.</description>
</event>
<event sqlsat="15">
      <importID>462</importID>
      <speaker>Michael Antonovich</speaker>
      <track>Room 1009 (Auditorium)</track>
      <location>
        <name>Room 1009</name>
      </location>
      <title>Save Time and Merge It</title>
      <description>The SQL Server 2008 MERGE command combines the features of the Insert and Update commands into a single powerful statement.  You can now insert new data into one table while also update or delete data from an existing table with a single statement.  In this session, we will take a look at this new addition to your TSQL toolbox in SQL Server 2008 to show how to merge two tables without creating duplicate records, how to synchronize two tables, how to use the OUTPUT clause with MERGE to save deleted records from the merge into an archival table, how indexing effects performance of MERGE statements and more.</description>
</event>
<event sqlsat="16">
      <importID>558</importID>
      <speaker>Michael Antonovich</speaker>
      <track>DBA4</track>
      <location>
        <name>Room 259</name>
      </location>
      <title>Save Time by Merging It</title>
      <description>The SQL Server 2008 MERGE command combines the features of the Insert and Update commands into a single powerful statement.  You can now insert new data into one table while also updating or deleting data from an existing table with a single statment.  In this sessionk we will explore this new addition to your TSQL toolbox in SQL Server 2008 to show how to merge two tables without creating duplicate records, how to synchronize two tables, how to use the OUTPUT clause with MERGE to save deleted records from the merge into an archival table, and how indexing effects the performance of MERGE statements and more.</description>
</event>
<event sqlsat="170">
      <importID>10992</importID>
      <speaker>Hugo Kornelis</speaker>
      <track>Track 1</track>
      <location>
        <name>Room 1</name>
      </location>
      <title>Everything you always wanted to know about MERGE</title>
      <description>... (but were afraid to ask)
In this demo-rich session, Hugo Kornelis shows how the full syntax of MERGE enables more than just synchronizing data. You''ll get an overview of all the available options, plus a few surprising pitfalls you may not be aware of.</description>
</event>
<event sqlsat="19">
      <importID>784</importID>
      <speaker>Chuck Heinzelman</speaker>
      <track>App Dev II</track>
      <location>
        <name>University of Iowa</name>
      </location>
      <title>SQL Server 2008 - Practical Uses for New Features</title>
      <description>When learning a new technology, I like to try to solve a real-world problem that will help me not only learn but also help me in my daily life.  Learning SQL Server 2008 was no exception for me.  Through the building of an electronic recipe box, I have taken advantage of many of the new features of SQL Server 2008 ?�� including sparse columns, filestream, table-valued parameters, the MERGE statement and even spatial data.  Come learn from my experiences as we walk through the design and development of this application ?�� and you can even have the code when we?��re done!</description>
</event>
<event sqlsat="20">
      <importID>186</importID>
      <speaker>Plamen Ratchev</speaker>
      <track>Main Auditorium</track>
      <location>
        <name>Main Auditorium</name>
      </location>
      <title>T-SQL Enhancements in SQL Server 2008</title>
      <description>This session will present new T-SQL enhancements in SQL Server 2008 including MERGE, table valued parameters, new data types (Date and Time related, FILESTREAM, HIERARCHYID), table value constructors, sparse columns, filtered indexes, delighters, and more.</description>
</event>
<event sqlsat="21">
      <importID>699</importID>
      <speaker>Rodney Landrum</speaker>
      <track>Administration (V006)</track>
      <location>
        <name>V006</name>
      </location>
      <title>Taking Control of SQL Server Error Logs</title>
      <description>The SQL Server Error Logs contain vital information for the day to day DBA. For 1 to 10 servers, reviewing the error logs can be an enlightening experience done manually. For 200+ servers it is more than a chore and automating the consolidation and analysis of the error log contents is essential to be a successful DBA. From failed login attemtps to data corruption, this session will show you how to maintain error log history, raise errors in code that will write to the error log and most importantly, centralize and report on specific errors across multiple servers. The solution will use several different technologies including SSIS and the MERGE statement, new to SQL Server 2008.</description>
</event>
<event sqlsat="22">
      <importID>1435</importID>
      <speaker>Rodney Landrum</speaker>
      <track>Room 2175 - SSIS</track>
      <location>
        <name>2175</name>
      </location>
      <title>DBA Repository Update 2010 Using SSIS and SSRS</title>
      <description>I put together the DBA Repository a few years back and have written and spoken about it for as many years with updates and enhancements over time. At it''s heart, the solution employs SSIS and SSRS and in late 2009 I updated it for performance and resiliency. You can read about the original solution in SQL Server Magazine. The latest update will be published in 2010. This will be a sneak peak at those enhancements. The session will cover some interesting uses of package variables and MERGE in SSIS with new reports as well.</description>
</event>
<event sqlsat="25">
      <importID>676</importID>
      <speaker>Audrey Hammonds</speaker>
      <track>Development</track>
      <location>
        <name>Room 2</name>
      </location>
      <title>The T-SQL Trifecta:  Enhancements for Everyone</title>
      <description>There have been many useful enhancements to T-SQL provided with SQL Server 2008 and 2005.  Come learn about three of them:  MERGE, TRY...CATCH, and multi-row INSERT statements.  If you''ve ever written an UpSert, given yourself carpal tunnel syndrome cutting and pasting INSERT statements, or conveniently forgotten to write in robust error handling because it was too cumbersome,  find out how T-SQL can work better for you and for your code.  </description>
</event>
<event sqlsat="27">
      <importID>1627</importID>
      <speaker>Todd McDermid</speaker>
      <track>Track 3</track>
      <location>
        <name>Franz 223</name>
      </location>
      <title>Dimension Processing with SSIS - Simple to Complex</title>
      <description>The SCD Wizard included in Integration Services is easy to use, and has all the features you need for smaller, simple dimension processing. However, it is not the easiest component to adjust, and doesn''t perform very well with larger dimensions. This session will cover three alternative techniques for processing changes to dimension tables within SSIS: ''rolling your own SCD'' with Lookups and Conditional Splits, using the T-SQL MERGE statement, and the Kimball Method SCD component. The strengths and weaknesses of each technique will be described and demonstrated.</description>
</event>
<event sqlsat="29">
      <importID>1349</importID>
      <speaker>Rodney Landrum</speaker>
      <track>Database Administration 2</track>
      <location>
        <name>HSB 129D</name>
      </location>
      <title>DBA Repository Update 2010 Using SSRS and SSIS. </title>
      <description>I put together the DBA Repository a few years back and have written and spoken about it for as many years with updates and enhancements over time. At it''s heart, the solution employs SSIS and SSRS and in late 2009 I updated it for performance and resiliency. You can read about the original solution in SQL Server Magazine. The latest update will be published in 2010. This will be a sneak peak at those enhancements. The session will cover some interesting uses of package variables and MERGE in SSIS with new reports as well.</description>
</event>
<event sqlsat="3">
      <importID>126</importID>
      <speaker>Plamen Ratchev</speaker>
      <track>Auditorium 1202</track>
      <location>
        <name>Auditorium 1202</name>
      </location>
      <title>SQL Server 2008 T-SQL Enhancements</title>
      <description>This session will present new T-SQL enhancements in SQL Server 2008. Learn how to use MERGE, table valued parameters, new data types (Date and Time related, FILESTREAM, HIERARCHYID), table value constructors, grouping sets, new table and query hints, sparse columns, filtered indexes, delighters, and more.</description>
</event>
<event sqlsat="32">
      <importID>924</importID>
      <speaker>Plamen Ratchev</speaker>
      <track>Track 3</track>
      <location>
        <name>Room 3</name>
      </location>
      <title>Refactoring SQL for Performance</title>
      <description>Many people live by the motto ?ǣIf it?��s not broken, don?��t fix it?ǥ. But if you believe that you are missing all enhancements introduced in newer versions of SQL Server (2005/2008). These new features can help you develop better solutions with improved performance, scalability, and maintainability. Learn how to craft a better query using the new MERGE statement, ranking functions, and more. Practical examples with tips and tricks.</description>
</event>
<event sqlsat="37">
      <importID>1495</importID>
      <speaker>Sharon Dooley</speaker>
      <track>Database Development-TSQL</track>
      <location>
        <name>Room 2</name>
      </location>
      <title>New Toys for Developers in SQL Server 2008</title>
      <description>This presentation will cover some of the important features for developers in SQL Server 2008. Topics covered include the FILESTREAM attribute, Change Data Capture, the MERGE statement and Row Constructors. There will be demos for most of the topics.</description>
</event>
<event sqlsat="38">
      <importID>1168</importID>
      <speaker>Plamen Ratchev</speaker>
      <track>1202 (Auditorium)</track>
      <location>
        <name>1202 (Auditorium)</name>
      </location>
      <title>Refactoring SQL for Performance</title>
      <description>Many people live by the motto ?ǣIf it?��s not broken, don?��t fix it?ǥ. But if you believe that you are missing all enhancements introduced in newer versions of SQL Server (2005/2008). These new features can help you develop better solutions with improved performance, scalability, and maintainability. Learn how to craft a better query using the new MERGE statement, ranking functions, and more. Practical examples with tips and tricks.</description>
</event>
<event sqlsat="40">
      <importID>1631</importID>
      <speaker>Rodney Landrum</speaker>
      <track>BI2</track>
      <location>
        <name>Room 2</name>
      </location>
      <title>DBA Repository Update 2010 Using SSIS and SSRS</title>
      <description>At it''s heart, the DBA Repository solution employs SSIS and SSRS and in late 2009 was updated  for performance and resiliency. This session will cover the original solution, published in SQL Server Magazine, plus the latest enhancements which will delve into some interesting uses of package variables and MERGE in SSIS along with some new reports. </description>
</event>
<event sqlsat="43">
      <importID>1793</importID>
      <speaker>Todd McDermid</speaker>
      <track>Room 2011</track>
      <location>
        <name>2011 - Pioneer Square</name>
      </location>
      <title>Data Warehouse Dimension Processing with SSIS</title>
      <description>The SCD Wizard included in Integration Services is easy to use, and has all the features you need for smaller, simple dimension processing. However, it is not the easiest component to adjust, and doesn''t perform very well with larger dimensions. This session will cover three alternative techniques for processing changes to dimension tables within SSIS: ''rolling your own SCD'' with Lookups and Conditional Splits, using the T-SQL MERGE statement, and the Kimball Method SCD component. The strengths and weaknesses of each technique will be described and demonstrated.</description>
</event>
<event sqlsat="48">
      <importID>2572</importID>
      <speaker>Brett Tomson</speaker>
      <track>DB Dev 1</track>
      <location>
        <name>218</name>
      </location>
      <title>T-SQL Enhancements in SQL Server 2008</title>
      <description>The release of SQL Server 2008 represents a paradigm shift in the way that we program T-SQL.  With new commands and new data types, 2008 provides the SQL developer with a bevy of options intended to make their development tasks easier.  In this session, we will explore what enhancements have been made to T-SQL including (but not limited to) row constructors, the MERGE statement, table-valued parameters as well as what new data types are available to us.</description>
</event>
<event sqlsat="52">
      <importID>2138</importID>
      <speaker>Jennifer McCown</speaker>
      <track>Dev</track>
      <location>
        <name>1</name>
      </location>
      <title>T-SQL Brush-up:The Best Things You Forgot You Knew</title>
      <description>You?��re a good SQL professional ?�� you attend conferences and webinars, you read articles and books, you know your way around SQL Server. But sometimes ?�� just SOMEtimes ?�� some piece of T-SQL slips by you unnoticed, or falls out of memory. Come and revisit old favorites, and brush up on new T-SQL features and enhancements like MERGE, OVER, and PARTITION BY. This session is chock full of code examples, including before-and-after demos and how-to illustrations.</description>
</event>
<event sqlsat="52">
      <importID>2290</importID>
      <speaker>Troy Ketsdever</speaker>
      <track>Dev/BI</track>
      <location>
        <name>4</name>
      </location>
      <title>Zero to ''MERGE'' in 60 Minutes</title>
      <description>SQL Server 2008 saw the introduction of the new MERGE DML statement. In this session, we''ll take a look at the basic syntax and capabilities of the command. Once we have reviewed some simple examples, we''ll dive into some of the more advanced uses (abuses?) of the command, reinforcing our understanding by looking at more complex examples.</description>
</event>
<event sqlsat="57">
      <importID>2737</importID>
      <speaker>Rodney Landrum</speaker>
      <track>Track 6</track>
      <location>
        <name>M 114</name>
      </location>
      <title>DBA Repository Update 2010 Using SSIS and SSRS</title>
      <description>At its heart, the DBA Repository solution employs SSIS and SSRS and in late 2009 was updated for performance and resiliency. This session will cover the original solution, published in SQL Server Magazine, plus the latest enhancements which will delve into some interesting uses of package variables and MERGE in SSIS along with some new reports.</description>
      <speaker>Dmitri Korotkevitch</speaker>
      <track>Track 4</track>
      <location>
        <name>Room C</name>
      </location>
      <title>Revive the code: refactoring for performance</title>
      <description>Stored procedures are slow? SQL Server is overloaded? Maybe it''s time to upgrade the server. But maybe all you need to do is the code refactoring. 
This session shows how to replace several common procedural style patterns in T-SQL code with set-based approaches. It demonstrates how to gain huge performance improvements using CTE, table-valued functions, TVP, MERGE operator, OUTPUT clause and other modern T-SQL constructs. No PowerPoint slides. Presentation is based on the real examples and real code.</description>
</event>
<event sqlsat="62">
      <importID>2833</importID>
      <speaker>Rodney Landrum</speaker>
      <track>Track 4</track>
      <location>
        <name>Room C</name>
      </location>
      <title>DBA Repository Update 2010 Using SSIS and SSRS </title>
      <description>At its heart, the DBA Repository solution employs SSIS and SSRS and in late 2009 was updated for performance and resiliency. This session will cover the original solution, published in SQL Server Magazine, plus the latest enhancements which will delve into some interesting uses of package variables and MERGE in SSIS along with some new reports.</description>
      <importID>3387</importID>
      <speaker>Alex Grinberg</speaker>
      <track>Dev Track #2 (111)</track>
      <location>
        <name>Room 111</name>
      </location>
      <title>Advance T-SQL technique  to optimize a code.</title>
      <description>In this session I''ll demonstrate how T-SQL code can be improved using latest features for  
SQL Server 2005 and up, such as CTE (Common Table Expression), OUTPUT clause, Ranking functions, EXCEPT, INTERSECT, XPath query, MERGE statement and others.</description>
</event>
<event sqlsat="8">
      <importID>183</importID>
      <speaker>Plamen Ratchev</speaker>
      <track>SQL 2008</track>
      <location>
        <name>J101</name>
      </location>
      <title>T-SQL Enhancements in SQL Server 2008</title>
      <description>This session will present new T-SQL enhancements in SQL Server 2008 including MERGE, table valued parameters, new data types (Date and Time related, FILESTREAM, HIERARCHYID), table value constructors, sparse columns, filtered indexes, delighters, and more.</description>
</event>
<event sqlsat="92">
      <importID>5261</importID>
      <speaker>Rob Garrison</speaker>
      <track>
      </track>
      <location>
        <name>306</name>
      </location>
      <title>Exploring SQL 2008''s MERGE</title>
      <description>MERGE is a new capability in SQL Server 2008. This session will start with the basics of what MERGE is and then dig into how it works and how it compares to using traditional INSERT/UPDATE semantics. You should come away from this session with a good understanding of MERGE, ready to implement it in your environment.</description>
</event>
<event sqlsat="96">
      <importID>4960</importID>
      <speaker>Wayne Sheffield</speaker>
      <track>Dev</track>
      <location>
        <name>5184</name>
      </location>
      <title>Banish RBAR!</title>
      <description>SQL Server is primarily designed for set-based operations, so code that performs Row-By-Agonizing-Row (RBAR) operations is going against the design, rather than working with it. Come to this code filled session, where we will examine several recent additions to SQL Server, and learn how the vast majority of RBAR code can be replaced with efficient, set-based code. Learn how the APPLY operator works; iterate through incoming data just once with the MERGE statement; ?ǣslice and dice?ǥ your data with the Windowing (ranking) functions; re-write your multi-statement table-valued functions to inline functions to help the optimizer and speed up your queries; learn how to create a grouped delimited list ?�� without loops!</description>
</event>
</events>'
-- http://www.sqlsaturday.com/viewsession.aspx?sat=10&sessionid=299
select x.value('./@sqlsat','int') SQLSat,
'http://www.sqlsaturday.com/viewsession.aspx?sat=' + x.value('./@sqlsat','varchar(4)') + '&sessionid=' + x.value('importID[1]','varchar(8)') SessionURL,
x.value('speaker[1]','varchar(50)') Speaker,
x.value('title[1]','varchar(50)') Title,
x.value('description[1]','varchar(500)') Description
from @x.nodes('/events/event') x(x)
--) select * from x