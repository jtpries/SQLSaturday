-- Other Neat queries

-- Non-US Events?
with SQLSatRaw(n,x) as (select n, CAST(x as xml) x from SQLSatXML)
, SQLSatVenue as (
select n, x.value('(//guide/name)[1]','varchar(100)') Event,
x.value('(//guide/startDate)[1]','date') Date,
x.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
x.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
x.value('(//venue/city)[1]', 'nvarchar(50)') City,
x.value('(//venue/state)[1]', 'nvarchar(50)') State,  
x.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
from SQLSatRaw)
SELECT * FROM SQLSatVenue
WHERE LEN(State)>2
ORDER BY City,n;


-- Most traveled speakers?

-- Handy Facts from Mladen:
-- Kosovo SQL Saturday had 30-40% women attendees, average attendee age 25


WITH SQLSat(n, XML) AS (SELECT n, CAST(x AS XML) XML FROM SQLSatXML)
, CityDates AS (SELECT n, 
	xml.value('(//guide/name)[1]','varchar(100)') Event,
	xml.value('(//guide/startDate)[1]','date') Date,
	xml.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
	xml.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
	xml.value('(//venue/city)[1]', 'nvarchar(50)') City,
	xml.value('(//venue/state)[1]', 'nvarchar(50)') State,
	xml.value('(//venue/zipcode)[1]', 'nvarchar(50)') Zip
FROM SQLSat)
INSERT Events(#, EventName, EventDate, VenueName, Street, City, State, Zip)
SELECT n, Event, Date, VenueName, Street, City, State, Zip
FROM CityDates;

SELECT * FROM Events;