/*	Hacking SQL Saturday
	Import XML Files to table
*/

-- command line (download CURL first):
-- for /L %a in (1,1,275) do curl -o %a.xml http://sqlsaturday.com/eventxml.aspx?sat=%a

USE HackingSQLSat;
--DROP TABLE SQLSatXML
CREATE TABLE SQLSatXML(n SMALLINT NOT NULL PRIMARY KEY,x VARCHAR(MAX) NULL);

--CREATE TABLE #sqlsatXML(n SMALLINT NOT NULL PRIMARY KEY,x VARCHAR(MAX) NULL);
--CREATE SYNONYM SQLSatXML FOR #sqlsatXML

-- loop through all events and insert
SET NOCOUNT ON;
DECLARE @n SMALLINT=1, @sql NVARCHAR(MAX);

WHILE @n<=275 BEGIN
	SET @sql=N'select ' + CAST(@n AS VARCHAR) + 
		', * from openrowset(bulk ''c:\HackingSQLSaturday\' + CAST(@n AS VARCHAR) +
		'.xml'', single_clob) x(xml)';
	INSERT SQLSatXML EXEC(@sql);
	SET @n+=1;
END

-- # 39 has corrupted data
DELETE SQLSatXML WHERE n=39;

-- now we can query across all events:
WITH SQLSat(n,x) AS (SELECT n, CAST(x AS XML) x FROM SQLSatXML)
, Events AS (
SELECT n, 
	x.value('(//guide/name)[1]','varchar(100)') Event,
	x.value('(//guide/startDate)[1]','date') Date,
	x.value('(//venue/name)[1]', 'nvarchar(200)') VenueName, 
	x.value('(//venue/street)[1]', 'nvarchar(100)') Street, 
	x.value('(//venue/city)[1]', 'nvarchar(50)') City,
	x.value('(//venue/state)[1]', 'nvarchar(50)') State,  
	x.value('(//venue/zipcode)[1]', 'nvarchar(50)') ZipCode 
FROM SQLSat)
SELECT * FROM Events;


/* -- clean up
DROP SYNONYM SQLSatXML;
DROP TABLE #sqlsatXML;
*/